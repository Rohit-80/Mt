import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  pure: false,
  name: 'multipleSelectionPipe'
})
export class MultipleSelectionPipePipe implements PipeTransform {

  transform(value, thisValue, bb?): any {
    return multipleFilter(value, thisValue, bb)
  }

  
}

export function multipleFilter(value, thisValue, bb) {

  // console.log(value, thisValue);
  const v: any = [];
  for(let p in value) {
    if (bb) {
      v.push(p);
      continue;
    }
     if (thisValue.findIndex(pa => pa?.id == p) < 0) {
       v.push(value[p]);
     }
  }

  return v;
}


// first edage default = all