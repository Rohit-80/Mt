import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormControl } from '@angular/forms';
import { switchMap, iif, of, delay, tap, Subscription, finalize } from 'rxjs';


@Component({
  selector: 'app-mat-select-multi',
  templateUrl: './mat-select-multi.component.html',
  styleUrls: ['./mat-select-multi.component.scss']
})
export class MatSelectMultiComponent implements OnInit {

  /** search filter ctrl */
  searchFilterCtrl = new FormControl('');
  /** mat form control */
  @Input() matFormCtrl = new FormControl([] as any);
  /** mat form control data */
  @Input() data: any = [];
  /** mat form control data */
  @Input() getDataFn: any = () => { };
  /** is All Checked */
  isAllChecked = true;
  /** initial data */
  @Input() initialData: any = [];
  /** current selected options */
  currentSelectedOptions = {};
  /** subscription */
  subs!: Subscription;
  /** 
   * null = default all options is selected
   * [] = default no options is selected
   * [x, y, x] = default these options are selected
   */
  @Input() default: [] | number[] | null = null;
  /** get current context value */
  @Output() getValues = new EventEmitter<any>(); 

  isManualAllUnchecked = false;

  everyMappedDataWithID = new Map();

  @Input() detailedData = false;

  loading  = false;



  /**
   *  ng after view init()
   */
  ngAfterViewInit() {
    this.getValues.emit(this.getVal);

    if (this.default === null) {
       this.isAllChecked = true;
    } else if (!this.default?.length) {
      this.isAllChecked = false;
      this.isManualAllUnchecked = true;
    } else {
      this.isAllChecked = false;
      this.matFormCtrl.setValue([...this.default?.map(v => v?.id)], {emitEvent: false});
      this.default?.forEach((v: any) => {
          if (v?.id)
        this.currentSelectedOptions[v.id] = v;
      });
      this.isManualAllUnchecked = true;

    }
    this.subs.add(this.getData('').subscribe());

  }

  compareById(a: any, b: any) {
    return a === b;
  }

  ngOnInit(): void {
    this.subs = new Subscription();
    this.subs.add(this.searchFilterCtrl.valueChanges.pipe(
      switchMap((search) => {
        return this.getData(search);
      })
    ).subscribe());
  }


  getData(search: any) {

    this.loading = true;
    return this.getDataFn(search).pipe(finalize(() => this.loading = false) ,tap((res: any) => {

      res.forEach(d => {
        this.everyMappedDataWithID.set(d?.id,  d);
      })
      console.log(this.default);
      this.data = this.clone(res);
      if (this.isAllChecked) {
        const oldValue = this.clone(this.matFormCtrl.value);
        let newValue = [...oldValue, ...this.data?.map(d => d?.id), 0];
        newValue = this.getUnique(this.clone(newValue));
        this.matFormCtrl.setValue(this.getUnique(this.clone(newValue)), { emitEvent: false });

      } 
      else if (this.searchFilterCtrl.value && this.default === null && !this.isManualAllUnchecked) {
        const notvisited = this.data?.filter(v => !this.currentSelectedOptions?.[v?.id]?.id);
        if (notvisited?.length) {
          const oldValue = this.clone(this.matFormCtrl.value);
          let newValue = [...oldValue, ...notvisited?.map(v => v?.id)];
          if (notvisited.length == this.data.length) {
            newValue.push(0);
          } else {
            newValue = newValue.filter(v => v != 0);
          }
          newValue = this.getUnique(this.clone(newValue));
          this.matFormCtrl.setValue(this.clone(newValue), { emitEvent: false });
        }
      }

      if (!search) {

        // after clear search
        let vvv = this.matFormCtrl.value;
        const al = [...Object.keys(this.currentSelectedOptions), ...this.initialData?.map(v => v?.id)];
        if (al.every(v => vvv.includes(+v))) {
          vvv.push(0);
        } else {
          vvv = vvv.filter(v => v != 0);
        }

        this.matFormCtrl.setValue(this.getUnique(vvv), { emitEvent: false })
      } else {
        // after search has value
        let vvv = this.matFormCtrl.value;
        const al = [...this.data?.map(d => d?.id)];
        if (al.every(v => vvv.includes(+v))) {
          vvv.push(0);
        } else {
          vvv = vvv.filter(v => v != 0);
        }
        this.matFormCtrl.setValue(this.getUnique(vvv), { emitEvent: false })
      }

      if (!this.isAllChecked && this.searchFilterCtrl.value  && this.default === null && !this.isManualAllUnchecked) {
        const notvisited = this.data?.filter(v => !this.currentSelectedOptions?.[v?.id]?.id);
        if (notvisited?.length) {
          const oldValue = this.clone(this.matFormCtrl.value);
          let newValue = [...oldValue, ...notvisited?.map(v => v?.id)];
          if (notvisited.length == this.data.length) {
            newValue.push(0);
          } else {
            newValue = newValue.filter(v => v != 0);
          }
          newValue = this.getUnique(this.clone(newValue));
          this.matFormCtrl.setValue(this.getUnique(this.clone(newValue)), { emitEvent: false });
        }
      }
    }));

    // let r = [];
    //   // if (search) {
    //   //   r = this.clone(this.allData.filter((v: any) => v?.id?.toString().includes(search))?.slice(0, 5));
    //   // } else {
    //   //   r = this.clone(this.allData?.slice(0, 5));
    //   // }

    //   return iif(() => !search, of(this.initialData),  of(r).pipe(delay(1000) )).pipe(tap(res => {
    //     // this.data = this.clone(res);
    //     // this.outerThis.afterAPIresponnse(res);
    //     // debugger;
    //     // if (this.isAllChecked) {

    //     //   const oldValue = this.clone(this.matFormCtrl.value);
    //     //    let newValue = [...oldValue, ...this.data?.map(d => d?.id), 0];
    //     //    newValue = this.getUnique(this.clone(newValue));
    //     //   this.matFormCtrl.setValue(this.clone(newValue), {emitEvent: false});

    //     // } else if (this.searchFilterCtrl.value) {

    //     //   const notvisited = this.data?.filter(v => !this.currentSelectedOptions?.[v?.id]?.id);
    //     //   if (notvisited?.length) {
    //     //     const oldValue = this.clone(this.matFormCtrl.value);
    //     //     let newValue = [...oldValue, ...notvisited?.map(v => v?.id)];
    //     //     if (notvisited.length == this.data.length) {
    //     //       newValue.push(0);
    //     //     } else {
    //     //       newValue = newValue.filter(v => v != 0);
    //     //     }
    //     //     newValue = this.getUnique(this.clone(newValue));
    //     //    this.matFormCtrl.setValue(this.clone(newValue), {emitEvent: false});
    //     //   }
    //     // }

    //     // if (!search) {

    //     //   // after clear search
    //     //   let vvv = this.matFormCtrl.value;
    //     //   const al = [...Object.keys(this.currentSelectedOptions), ...this.initialData?.map(v => v?.id)];
    //     //   if(al.every(v => vvv.includes(+v))) {
    //     //     vvv.push(0);
    //     //   } else {
    //     //     vvv = vvv.filter(v => v != 0);
    //     //   }

    //     //   this.matFormCtrl.setValue(vvv, {emitEvent: false})
    //     // } else {
    //     //   // after search has value
    //     //   let vvv = this.matFormCtrl.value;
    //     //   const al = [...this.data?.map(d => d?.id)];
    //     //   if(al.every(v => vvv.includes(+v))) {
    //     //     vvv.push(0);
    //     //   } else {
    //     //     vvv = vvv.filter(v => v != 0);
    //     //   }
    //     //   this.matFormCtrl.setValue(vvv, {emitEvent: false})


    //     // }

    //     // if (!this.isAllChecked && this.searchFilterCtrl.value) {
    //     //   debugger;
    //     //   const notvisited = this.data?.filter(v => !this.currentSelectedOptions?.[v?.id]?.id);
    //     //   if (notvisited?.length) {
    //     //     const oldValue = this.clone(this.matFormCtrl.value);
    //     //     let newValue = [...oldValue, ...notvisited?.map(v => v?.id)];
    //     //     if (notvisited.length == this.data.length) {
    //     //       newValue.push(0);
    //     //     } else {
    //     //       newValue = newValue.filter(v => v != 0);
    //     //     }
    //     //     newValue = this.getUnique(this.clone(newValue));
    //     //    this.matFormCtrl.setValue(this.clone(newValue), {emitEvent: false});
    //     //   }
    //     // }


    //   }));

  }

  trackById(index: number, item: any): number {
    return item?.id;
  }

  one(isSelected: any, id: any) {
    let vvv = this.matFormCtrl.value;
    if (isSelected) {
      vvv.push(id);
    } else {
      vvv = vvv.filter(ddd => ddd != id);
    }

    console.log('in one only', this.matFormCtrl.value);
    setTimeout(() => {
      debugger;
      console.log('form control value', this.matFormCtrl.value);
      if (this.data?.find(dat => dat?.id == id))
        this.currentSelectedOptions[id] = this.clone(this.data?.find(dat => dat?.id == id));

      if (this.searchFilterCtrl.value) {
        if (this.data.every(d => vvv.includes(d?.id))) {
          vvv.push(0);
        } else {
          vvv = vvv.filter(v => v != 0);
        }
      } else {
        const al = [...Object.keys(this.currentSelectedOptions), ...this.data?.map(v => v?.id)];
        if (al.every(v => vvv.includes(+v))) {
          vvv.push(0);
        } else {
          vvv = vvv.filter(v => v != 0);
        }
      }

      this.matFormCtrl.setValue(this.getUnique(vvv), { emitEvent: false });


      // for isAllChecked
      if (!this.searchFilterCtrl.value) {
        if (isSelected) {

          if ([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v)].every(v => this.matFormCtrl.value.includes(+v))) {

            this.isAllChecked = true;
          }
          //  this.matFormCtrl.setValue([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0], {emitEvent: false})

        } else {
          this.isAllChecked = false;
        }
      } else {

        if ([...this.initialData?.map(v => v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), ...this.data?.map(v => v?.id)].every(v => this.matFormCtrl.value?.includes(v))) {
          this.isAllChecked = true;
        } else {
          this.isAllChecked = false;
        }
        //   if (isSelected) {
        //     this.matFormCtrl.setValue([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0], {emitEvent: false})
        //   } else {
        //   //  this.isAllChecked = false;
        //    this.matFormCtrl.setValue([], {emitEvent: false})
        //  }
      }

      console.log(isSelected, id);
    }, 100)
  }

  all(isSelected: any, id: any, value) {
    debugger;
    console.log('in all only', this.matFormCtrl.value, value);

    const vvv = this.matFormCtrl.value;

    setTimeout(() => {


      // debugger
      this.data.forEach(element => {
        this.currentSelectedOptions[element?.id] = this.clone(element);

      });
      // debugger;
      console.log(isSelected, id, this.currentSelectedOptions);

      const oldValue = this.clone(vvv);
      if (isSelected) {
        const newValue = [...oldValue, ...(this.data?.map((a: any) => a?.id)), 0];
        const uniqueValues = [...new Set(this.clone(newValue))];

        console.log('qq', uniqueValues);
        this.matFormCtrl.setValue(this.clone(uniqueValues), { emitEvent: false });
      } else {
        const newValue = [...oldValue?.filter(d => !this.data?.find(v => v?.id == d) && d != id)];
        const uniqueValues = [...new Set((this.clone(newValue)))];

        console.log('qq', uniqueValues);
        this.matFormCtrl.setValue(this.clone(uniqueValues), { emitEvent: false });
      }

      // for isAllChecked
      if (!this.searchFilterCtrl.value) {
        if (isSelected) {
          this.isAllChecked = true;
          this.matFormCtrl.setValue(this.getUnique([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0]), { emitEvent: false })
          this.isManualAllUnchecked = false;
        } else {
          this.isAllChecked = false;
          this.matFormCtrl.setValue([], { emitEvent: false });
          this.isManualAllUnchecked = true;

        }
      } else {

        if ([...this.initialData?.map(v => v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v)].every(v => this.matFormCtrl.value?.includes(v))) {
          this.isAllChecked = true;
        } else {
          this.isAllChecked = false;
        }
        //   if (isSelected) {
        //     this.matFormCtrl.setValue([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0], {emitEvent: false})
        //   } else {
        //   //  this.isAllChecked = false;
        //    this.matFormCtrl.setValue([], {emitEvent: false})
        //  }
      }
    }, 100);


  }

  // clickOne(id: any) {
  //   console.log(id, this.outerThis);
  // }


  getUnique(newValue): any[] {
    return [...new Set(newValue)];
  }

  clone(arr) {
    return typeof arr == 'object' ? JSON.parse(JSON.stringify(arr)) : arr;
  }

  getVal = () => {
    // return {
    //   isAll: this.isAllChecked,
    //   selected: [],
    //   unSelected: [],
    //   /** optimal includes based on min value */
    //   includes: true
    // }

    let isAll = false, selected: any = [], unSelected: any = [];
    let el = [...this.initialData?.map(v => v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), ...this.data?.map(v => v?.id)];
    console.log(el);
    if (el.every(v => this.matFormCtrl.value?.includes(v))) {
      isAll = true;
    }

    selected = this.getUnique(this.matFormCtrl.value);

    unSelected = [...this.initialData?.map(v => v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), ...this.data?.map(v => v?.id)].filter(v => !this.matFormCtrl.value?.includes(v));
    unSelected = this.getUnique(unSelected);

   const data = {
      isAll,
      selected,
      unSelected,
      includes: selected?.length < unSelected 
    }
    if (this.detailedData) {
      data['selected'] = data['selected']?.map(v => this.everyMappedDataWithID.get(v) || {id: v});
      data['unSelected'] = data['unSelected']?.map(v => this.everyMappedDataWithID.get(v) || {id: v});
    }
    return data;
  }
  
}
