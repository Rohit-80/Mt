import { Directive, EventEmitter, Input, Output } from '@angular/core';

@Directive({
  selector: '[appMultipleSelectiond]'
})
export class MultipleSelectiondDirective {

   self = this;
   public clickOne = (id) => {
     console.log('====================', id)
    }
    sp = 'a';

     @Input() doct: any = null;

    @Input() bankFilterCtrl: any = null;


    @Input() data: any = [];

    @Input() initialSize: any = [];

    @Input() currentSelectedOptions = {};

    isAllChecked = true;


  @Output() ev = new EventEmitter<any>();
  constructor() {
    console.log('directive init');
    this.ev.emit(this.self);
   }

   ngOnInit() {
    console.log('directive init');
    this.ev.emit(this.self);
  }




  public one = (isSelected: any, id: any) => {
    let vvv = this.doct.value;
    if (isSelected) {
      vvv.push(id);
    } else {
      vvv = vvv.filter(ddd => ddd != id);
    }

    console.log('in one only',  this.doct.value);
    setTimeout(() => {
      debugger;
      console.log('form control value', this.doct.value);
      if (this.data?.find(dat => dat?.id == id))
      this.currentSelectedOptions[id] = this.clone(this.data?.find(dat => dat?.id == id));

      if (this.bankFilterCtrl.value) {
         if (this.data.every(d => vvv.includes(d?.id))) {
           vvv.push(0);
         } else {
          vvv = vvv.filter(v => v != 0);
         }
      } else {
        const al = [...Object.keys(this.currentSelectedOptions), ...this.data?.map(v => v?.id)];
        if(al.every(v => vvv.includes(+v))) {
          vvv.push(0);
        } else {
          vvv = vvv.filter(v => v != 0);
        }
      }

      this.doct.setValue(vvv, {emitEvent: false});


          // for isAllChecked
          if (!this.bankFilterCtrl.value) {
            if (isSelected) {

              if ([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v)].every(v => this.doct.value.includes(+v))) {

                this.isAllChecked = true;
              }
                        //  this.doct.setValue([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0], {emitEvent: false})
  
            } else {
              this.isAllChecked = false;
            }
        } else {
  
          if ([...this.initialSize?.map(v => v?.id),  ...Object.keys(this.currentSelectedOptions).map(v => +v), this.data?.map(v => v?.id)].every(v => this.doct.value?.includes(v))) {
            this.isAllChecked = true;
          } else {
            this.isAllChecked = false;
          }
        //   if (isSelected) {
        //     this.doct.setValue([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0], {emitEvent: false})
        //   } else {
        //   //  this.isAllChecked = false;
        //    this.doct.setValue([], {emitEvent: false})
        //  }
        }

      console.log(isSelected, id);
    }, 100)
  }

  public all = (isSelected: any, id: any, value) => {
    debugger;
    console.log('in all only', this.doct.value, value);

     const vvv = this.doct.value;

    setTimeout(() => {

      
      // debugger
      this.data.forEach(element => {
        this.currentSelectedOptions[element?.id] = this.clone(element);
        
      });
  // debugger;
      console.log(isSelected, id, this.currentSelectedOptions);

      const oldValue = this.clone(vvv);
      if (isSelected) {
        const newValue = [...oldValue, ...(this.data?.map((a: any) => a?.id)), 0];
        const uniqueValues = [...new Set(this.clone(newValue))];

        console.log('qq', uniqueValues);
        this.doct.setValue(this.clone(uniqueValues), {emitEvent: false});
      } else {
        const newValue = [...oldValue?.filter(d => !this.data?.find(v=>v?.id == d) && d != id)];
        const uniqueValues = [...new Set((this.clone(newValue)))];

        console.log('qq', uniqueValues);
        this.doct.setValue(this.clone(uniqueValues), {emitEvent: false});
      }

      // for isAllChecked
      if (!this.bankFilterCtrl.value) {
          if (isSelected) {
             this.isAllChecked = true;
                       this.doct.setValue([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0], {emitEvent: false})

          } else {
            this.isAllChecked = false;
            this.doct.setValue([], {emitEvent: false})
          }
      } else {

        if ([...this.initialSize?.map(v => v?.id),  ...Object.keys(this.currentSelectedOptions).map(v => +v)].every(v => this.doct.value?.includes(v))) {
          this.isAllChecked = true;
        } else {
          this.isAllChecked = false;
        }
      //   if (isSelected) {
      //     this.doct.setValue([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0], {emitEvent: false})
      //   } else {
      //   //  this.isAllChecked = false;
      //    this.doct.setValue([], {emitEvent: false})
      //  }
      }
    }, 100);


  }

  public afterAPIresponnse = (res) => {
    this.data = this.clone(res);
    debugger;
    if (this.isAllChecked) {
      
      const oldValue = this.clone(this.doct.value);
       let newValue = [...oldValue, ...this.data?.map(d => d?.id), 0];
       newValue = this.getUnique(this.clone(newValue));
      this.doct.setValue(this.clone(newValue), {emitEvent: false});
      
    } else if (this.bankFilterCtrl.value) {
      
      const notvisited = this.data?.filter(v => !this.currentSelectedOptions?.[v?.id]?.id);
      if (notvisited?.length) {
        const oldValue = this.clone(this.doct.value);
        let newValue = [...oldValue, ...notvisited?.map(v => v?.id)];
        if (notvisited.length == this.data.length) {
          newValue.push(0);
        } else {
          newValue = newValue.filter(v => v != 0);
        }
        newValue = this.getUnique(this.clone(newValue));
       this.doct.setValue(this.clone(newValue), {emitEvent: false});
      }
    }

    if (!this.bankFilterCtrl.value) {

      // after clear search
      let vvv = this.doct.value;
      const al = [...Object.keys(this.currentSelectedOptions), ...this.initialSize?.map(v => v?.id)];
      if(al.every(v => vvv.includes(+v))) {
        vvv.push(0);
      } else {
        vvv = vvv.filter(v => v != 0);
      }

      this.doct.setValue(vvv, {emitEvent: false})
    } else {
      // after search has value
      let vvv = this.doct.value;
      const al = [...this.data?.map(d => d?.id)];
      if(al.every(v => vvv.includes(+v))) {
        vvv.push(0);
      } else {
        vvv = vvv.filter(v => v != 0);
      }
      this.doct.setValue(vvv, {emitEvent: false})


    }

    if (!this.isAllChecked && this.bankFilterCtrl.value) {
      debugger;
      const notvisited = this.data?.filter(v => !this.currentSelectedOptions?.[v?.id]?.id);
      if (notvisited?.length) {
        const oldValue = this.clone(this.doct.value);
        let newValue = [...oldValue, ...notvisited?.map(v => v?.id)];
        if (notvisited.length == this.data.length) {
          newValue.push(0);
        } else {
          newValue = newValue.filter(v => v != 0);
        }
        newValue = this.getUnique(this.clone(newValue));
       this.doct.setValue(this.clone(newValue), {emitEvent: false});
      }
    }

  }

  getUnique(newValue) {
    return newValue;
 }

 clone(arr) {
   return typeof arr == 'object' ? JSON.parse(JSON.stringify(arr)) : arr;
 }

}
