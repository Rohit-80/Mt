import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { delay, iif, of, switchMap, tap } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  outerThis: any = null; 
  title = 'my-angular14-app';

  bankFilterCtrl = new FormControl('');
  doct = new FormControl([] as any);

  allData: any = [];
  data: any = [];

  isAllChecked = true;

  initialSize: any = [];

  getVal = () => {};

  currentSelectedOptions = {};
  compareById(a: any, b: any) {
    return a === b;
  }

  ngOnInit(): void {
    let i = 1;
    this.allData = Array.from({length: 200}).map( () => ({id: i, value: i++}))
    this.data = this.clone(this.allData.slice(0, 5));
    this.initialSize =  this.clone(this.allData.slice(0, 5));

    console.log(this.allData);
    
    this.doct.valueChanges.subscribe(v => {
      console.log('in values changes', v);
      console.trace(v);

    });

    (this.bankFilterCtrl.valueChanges.pipe(
      switchMap((search) => {
         return this.getData(search);
      })
    ).subscribe());

    this.getData('').subscribe();
  }

  onSearch(search) {
    this.bankFilterCtrl.setValue(search)
  }


  getData(search: any) {

    console.log('search', search);
    
    let r = [];
      if (search) {
        r = this.clone(this.allData.filter((v: any) => v?.id?.toString().includes(search))?.slice(0, 5));
      } else {
        r = this.clone(this.allData?.slice(0, 5));
      }

      return iif(() => !search, of(this.initialSize),  of(r).pipe(delay(1000) )).pipe(tap(res => {
        this.data = this.clone(res);
        // this.outerThis.afterAPIresponnse(res);
        // debugger;
        // if (this.isAllChecked) {
          
        //   const oldValue = this.clone(this.doct.value);
        //    let newValue = [...oldValue, ...this.data?.map(d => d?.id), 0];
        //    newValue = this.getUnique(this.clone(newValue));
        //   this.doct.setValue(this.clone(newValue), {emitEvent: false});
          
        // } else if (this.bankFilterCtrl.value) {
          
        //   const notvisited = this.data?.filter(v => !this.currentSelectedOptions?.[v?.id]?.id);
        //   if (notvisited?.length) {
        //     const oldValue = this.clone(this.doct.value);
        //     let newValue = [...oldValue, ...notvisited?.map(v => v?.id)];
        //     if (notvisited.length == this.data.length) {
        //       newValue.push(0);
        //     } else {
        //       newValue = newValue.filter(v => v != 0);
        //     }
        //     newValue = this.getUnique(this.clone(newValue));
        //    this.doct.setValue(this.clone(newValue), {emitEvent: false});
        //   }
        // }

        // if (!search) {

        //   // after clear search
        //   let vvv = this.doct.value;
        //   const al = [...Object.keys(this.currentSelectedOptions), ...this.initialSize?.map(v => v?.id)];
        //   if(al.every(v => vvv.includes(+v))) {
        //     vvv.push(0);
        //   } else {
        //     vvv = vvv.filter(v => v != 0);
        //   }

        //   this.doct.setValue(vvv, {emitEvent: false})
        // } else {
        //   // after search has value
        //   let vvv = this.doct.value;
        //   const al = [...this.data?.map(d => d?.id)];
        //   if(al.every(v => vvv.includes(+v))) {
        //     vvv.push(0);
        //   } else {
        //     vvv = vvv.filter(v => v != 0);
        //   }
        //   this.doct.setValue(vvv, {emitEvent: false})


        // }

        // if (!this.isAllChecked && this.bankFilterCtrl.value) {
        //   debugger;
        //   const notvisited = this.data?.filter(v => !this.currentSelectedOptions?.[v?.id]?.id);
        //   if (notvisited?.length) {
        //     const oldValue = this.clone(this.doct.value);
        //     let newValue = [...oldValue, ...notvisited?.map(v => v?.id)];
        //     if (notvisited.length == this.data.length) {
        //       newValue.push(0);
        //     } else {
        //       newValue = newValue.filter(v => v != 0);
        //     }
        //     newValue = this.getUnique(this.clone(newValue));
        //    this.doct.setValue(this.clone(newValue), {emitEvent: false});
        //   }
        // }


      }));



   



   
  }

  trackById(index: number, item: any): number {
    return item?.id;
  }

  // one(isSelected: any, id: any) {
  //   let vvv = this.doct.value;
  //   if (isSelected) {
  //     vvv.push(id);
  //   } else {
  //     vvv = vvv.filter(ddd => ddd != id);
  //   }

  //   console.log('in one only',  this.doct.value);
  //   setTimeout(() => {
  //     debugger;
  //     console.log('form control value', this.doct.value);
  //     if (this.data?.find(dat => dat?.id == id))
  //     this.currentSelectedOptions[id] = this.clone(this.data?.find(dat => dat?.id == id));

  //     if (this.bankFilterCtrl.value) {
  //        if (this.data.every(d => vvv.includes(d?.id))) {
  //          vvv.push(0);
  //        } else {
  //         vvv = vvv.filter(v => v != 0);
  //        }
  //     } else {
  //       const al = [...Object.keys(this.currentSelectedOptions), ...this.data?.map(v => v?.id)];
  //       if(al.every(v => vvv.includes(+v))) {
  //         vvv.push(0);
  //       } else {
  //         vvv = vvv.filter(v => v != 0);
  //       }
  //     }

  //     this.doct.setValue(vvv, {emitEvent: false});


  //         // for isAllChecked
  //         if (!this.bankFilterCtrl.value) {
  //           if (isSelected) {

  //             if ([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v)].every(v => this.doct.value.includes(+v))) {

  //               this.isAllChecked = true;
  //             }
  //                       //  this.doct.setValue([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0], {emitEvent: false})
  
  //           } else {
  //             this.isAllChecked = false;
  //           }
  //       } else {
  
  //         if ([...this.initialSize?.map(v => v?.id),  ...Object.keys(this.currentSelectedOptions).map(v => +v), this.data?.map(v => v?.id)].every(v => this.doct.value?.includes(v))) {
  //           this.isAllChecked = true;
  //         } else {
  //           this.isAllChecked = false;
  //         }
  //       //   if (isSelected) {
  //       //     this.doct.setValue([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0], {emitEvent: false})
  //       //   } else {
  //       //   //  this.isAllChecked = false;
  //       //    this.doct.setValue([], {emitEvent: false})
  //       //  }
  //       }

  //     console.log(isSelected, id);
  //   }, 100)
  // }

  // all(isSelected: any, id: any, value) {
  //   debugger;
  //   console.log('in all only', this.doct.value, value);

  //    const vvv = this.doct.value;

  //   setTimeout(() => {

      
  //     // debugger
  //     this.data.forEach(element => {
  //       this.currentSelectedOptions[element?.id] = this.clone(element);
        
  //     });
  // // debugger;
  //     console.log(isSelected, id, this.currentSelectedOptions);

  //     const oldValue = this.clone(vvv);
  //     if (isSelected) {
  //       const newValue = [...oldValue, ...(this.data?.map((a: any) => a?.id)), 0];
  //       const uniqueValues = [...new Set(this.clone(newValue))];

  //       console.log('qq', uniqueValues);
  //       this.doct.setValue(this.clone(uniqueValues), {emitEvent: false});
  //     } else {
  //       const newValue = [...oldValue?.filter(d => !this.data?.find(v=>v?.id == d) && d != id)];
  //       const uniqueValues = [...new Set((this.clone(newValue)))];

  //       console.log('qq', uniqueValues);
  //       this.doct.setValue(this.clone(uniqueValues), {emitEvent: false});
  //     }

  //     // for isAllChecked
  //     if (!this.bankFilterCtrl.value) {
  //         if (isSelected) {
  //            this.isAllChecked = true;
  //                      this.doct.setValue([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0], {emitEvent: false})

  //         } else {
  //           this.isAllChecked = false;
  //           this.doct.setValue([], {emitEvent: false})
  //         }
  //     } else {

  //       if ([...this.initialSize?.map(v => v?.id),  ...Object.keys(this.currentSelectedOptions).map(v => +v)].every(v => this.doct.value?.includes(v))) {
  //         this.isAllChecked = true;
  //       } else {
  //         this.isAllChecked = false;
  //       }
  //     //   if (isSelected) {
  //     //     this.doct.setValue([...this.data?.map(v => +v?.id), ...Object.keys(this.currentSelectedOptions).map(v => +v), 0], {emitEvent: false})
  //     //   } else {
  //     //   //  this.isAllChecked = false;
  //     //    this.doct.setValue([], {emitEvent: false})
  //     //  }
  //     }
  //   }, 100);


  // }

  clickOne(id: any) {
    console.log(id, this.outerThis);
  }


  getUnique(newValue) {
     return newValue;
  }

  clone(arr) {
    return typeof arr == 'object' ? JSON.parse(JSON.stringify(arr)) : arr;
  }

  gett() {
    console.log(this.getVal?.())
    // setInterval(() => {
    //   console.log(this.getVal?.())
    // }, 2000);
  }
}
